TC PlugMan jest mened�erem wtyczek dla Total Commandera.
Do jego mo�liwo�ci zaliczy� mo�na:

- przegl�danie listy wszystkich zainstalowanych wtyczek Listera/system�w
  plik�w/archiw�w
- dodawanie/usuwanie wtyczek (�atwiej, ni� w TC!)
- wy��czanie/w��czanie wtyczek (TC tego nie potrafi!)
- konfigurowanie wtyczek
- uruchamianie/restartowanie TC

Pozwala tak�e sprawdzi�, czy TC w danej chwili dzia�a. Je�li tak, wtedy
po dokonaniu zmian b�dziesz musia� zrestartowa� TC aby zmiany odnios�y skutek.

Przetestowano (i stwierdzono poprawne dzia�anie) przy u�yciu bie��cych wersji
Freeware/Open-Source.


Copyright (c) 2004-2007 Alexey Torgashin <atorg@yandex.ru>
http://atorg.net.ru
http://totalcmd.net/plugring/tc_plugman.html

T�umaczenie pliku Readme: Mateusz Bili�ski 'Myszor' <myszor@kolej.pl>
