uLister + Text Search + Document Converter (C) Egor Vlaznev 2011

1. About
uLister is a powerful document viewer which can open more than 500 file formats.
Text Search allow search files and all level attachment contain the specified text in the file search dialog.
Document Converter allow convert files to text,pdf,html,mhtml.

2. Supported files formats
Many popular word processing, spreadsheet, presentation, raster and vector image.
Full list:
http://www.oracle.com/technetwork/middleware/content-management/ds-oitfiles-133032.pdf

3. License
This software are provided "as-is". No warranty provided.
This plugin is freeware, but libraries from Oracle� is not, you must accept license 
http://www.oracle.com/technetwork/licenses/standard-license-152015.html
before using.

4. Credits
uLister plugin is using:
Outside In Viewer � 1991, 2010 Oracle.
Outside In Search Export � 1991, 2010 Oracle.
Outside In PDF Export � 1991, 2010 Oracle.
Outside In HTML Export � 1991, 2010 Oracle.
The software is based in part on the work of the Independent JPEG Group.
"inih" library (c) 2009, Brush Technology

5. Configuration
Use ulister.ini in plugin dir.
Section [filetypes]
Parameter "noloadtypes" allow disable plugin for some formats.  
Parameter "onlyloadtypes" allow enable plugin only for some formats.  
Parameter "nopreviewtypes" allow disable create preview for some formats.  
Parameter "onlypreviewtypes" allow enable create preview only for some formats.  
Parameter "nosearchtypes" allow disable search files contain text for some format.  
Parameter "onlysearchtypes" allow enable search files contain text only for some format.  
See formats list in vw-8-3-5-win-x86-32.zip\sdk\common\sccfi.h

Section [dllload]
Parameter "keepinmemory" allow keep Outside In Viewer library in memory, it reduce document load time but increase memory consumption.
Parameter "oitdir" contain folder path for save settings("oitdir=." - plugin folder)

6. Installation
Lister plugin:
Install plugin from archive.
Download vw-8-3-5-win-x86-32.zip: Viewer Technology 8.3.5 Windows (x86-32) from
http://www.oracle.com/technetwork/middleware/content-management/downloads/oit-dl-otn-097435.html ,
you need accept license and register for this.
Copy "redist" folder to plugin folder.
Content plugin:
Install ulister.wlx like wdx plugin.
Download sx-8-3-5-win-x86-32.zip: Search Export 8.3.5 Windows (x86-32) from
http://www.oracle.com/technetwork/middleware/content-management/downloads/oit-dl-otn-097435.html ,
you need accept license and register for this.
Copy "redist" folder to plugin folder, without file replacement.

Document Converter:
text:
Download sx-8-3-5-win-x86-32.zip: Search Export 8.3.5 Windows (x86-32) from
http://www.oracle.com/technetwork/middleware/content-management/downloads/oit-dl-otn-097435.html ,
you need accept license and register for this.
Copy "redist" folder to plugin folder, without file replacement.
pdf:
Download px-8-3-5-win-x86-32.zip: PDF Export 8.3.5 Windows (x86-32) from
http://www.oracle.com/technetwork/middleware/content-management/downloads/oit-dl-otn-097435.html ,
you need accept license and register for this.
Copy "redist" folder to plugin folder, without file replacement.
html,mhtml:
Download hx-8-3-5-win-x86-32.zip: HTML Export 8.3.5 Windows (x86-32) from
http://www.oracle.com/technetwork/middleware/content-management/downloads/oit-dl-otn-097435.html ,
you need accept license and register for this.
Copy "redist" folder to plugin folder, without file replacement.


7. Shortcut
Ctrl S - Convertion dialog
Ctrl + - Zoom In
Ctrl - - Zoom Out

8. History
1.3.0 (09.02.2011)
Added conversion feature, you can convert files to txt,pdf,html,mhtml.
1.2.1 (03.02.2011)
�ontent plugin speed dramatically increased. 
1.2.0 (03.02.2011)
Added content plugin function for search files contain the specified text.
1.1.0 (29.01.2011)
Fixed critical bug: vector image loading now working stable.
Fixed html navigation.
Added ListGetPreviewBitmap,ListGetPreviewBitmapW
1.0.4 (22.01.2011)
Fixed vertical scroll.
Added horizontal scroll, if your mouse support it.
Added zoom hotkey: Ctrl +/- or mouse scroll
Fixed search, Shift F3 now works.
1.0.3 (21.01.2011)
Fixed serious bug introduced in 1.0.2 version
New option in oilister.ini allow keep Outside In Viewer library in memory, it reduce document load time but increase memory consumption.
1.0.2 (21.01.2011)
Attachments support now really work for Total Commander 7.50 and higher.
Automatic saving option on exit.
1.0.1 (21.01.2011)
All dll now load dynamically, older Total Commander version and another programs that use wlx plugin now supported.
Added attachments support for Total Commander 7.50 and higher
1.0.0 (20.01.2011)
Initial release
